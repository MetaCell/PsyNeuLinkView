#!/bin/bash
source ~/.bashrc
source ~/.profile